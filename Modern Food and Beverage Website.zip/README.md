
  # Modern Food and Beverage Website

  This is a code bundle for Modern Food and Beverage Website. The original project is available at https://www.figma.com/design/VrFPCR4ODOGkDR3ilh2ynE/Modern-Food-and-Beverage-Website.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  